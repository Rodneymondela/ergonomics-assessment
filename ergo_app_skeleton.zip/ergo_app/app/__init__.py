import os
from flask import Flask
from .extensions import db, login_manager
from .config import Config

from .blueprints.auth import bp as auth_bp
from .blueprints.org import bp as org_bp
from .blueprints.jobs import bp as jobs_bp
from .blueprints.assessments import bp as assess_bp
from .blueprints.media import bp as media_bp
from .blueprints.api import bp as api_bp

from .models import user, org, ergo, media  # noqa

def create_app(config_object: type | None = None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object or Config())

    os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

    db.init_app(app)
    login_manager.init_app(app)

    app.register_blueprint(auth_bp)
    app.register_blueprint(org_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(assess_bp)
    app.register_blueprint(media_bp)
    app.register_blueprint(api_bp, url_prefix="/api")

    @app.cli.command("db-init")
    def db_init():
        with app.app_context():
            db.create_all()
            print("Database initialized")

    return app

from .extensions import db  # re-export for manage.py
