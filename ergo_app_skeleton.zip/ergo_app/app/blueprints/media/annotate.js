// TODO: Implement a canvas-based rectangle annotator. Stub for now.
