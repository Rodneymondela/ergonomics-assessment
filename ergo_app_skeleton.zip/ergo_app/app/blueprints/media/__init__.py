from flask import Blueprint
bp = Blueprint('media', __name__, template_folder='../../templates/media', static_folder='../../static')
from . import routes  # noqa
