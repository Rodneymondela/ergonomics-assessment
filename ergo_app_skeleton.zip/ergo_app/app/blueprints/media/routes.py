import os
from flask import send_from_directory, render_template, request, redirect, url_for, flash, current_app
from flask_login import login_required
from ...extensions import db
from ...models.media import Media
from . import bp

@bp.route('/media/<path:filename>')
@login_required
def serve(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)

@bp.route('/media/<int:media_id>/annotate', methods=['GET','POST'])
@login_required
def annotate(media_id):
    m = db.session.get(Media, media_id)
    if request.method == 'POST':
        m.annotations_json = request.form.get('annotations_json','[]')
        db.session.commit(); flash('Annotations saved','success')
        return redirect(url_for('assessments.view', assessment_id=m.assessment_id))
    return render_template('media/annotate.html', m=m)
