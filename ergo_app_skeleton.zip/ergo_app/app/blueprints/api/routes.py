from flask import jsonify
from ...models.ergo import Assessment
from . import bp

@bp.get('/assessments')
def list_assessments():
    rows = Assessment.query.order_by(Assessment.created_at.desc()).limit(50).all()
    return jsonify([
        dict(id=a.id, jobrole_id=a.jobrole_id, rula=a.rula, reba=a.reba, niosh_li=a.niosh_li, category=a.risk_category,
             created=a.created_at.isoformat()) for a in rows
    ])
