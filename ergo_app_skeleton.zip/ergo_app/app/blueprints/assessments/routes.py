import os, uuid
from flask import render_template, redirect, url_for, flash, request, current_app
from flask_login import login_required, current_user
from ...extensions import db
from ...models.org import Company, JobRole
from ...models.ergo import Assessment, CorrectiveAction
from ...models.media import Media
from ...scoring import compute_rula_full, compute_reba_full, risk_band
from ...scoring.niosh import compute_niosh
from . import bp
from .forms import AssessmentForm

@bp.route('/assessment/new', methods=['GET','POST'])
@login_required
def new():
    form = AssessmentForm()
    form.jobrole_id.choices = [(jr.id, f"{jr.title}") for jr in JobRole.query.join(Company).filter(Company.owner_id==current_user.id)]
    if form.validate_on_submit():
        rula = compute_rula_full(dict(
            upper_arm=form.rula_upper_arm.data, lower_arm_band=form.rula_lower_arm_band.data,
            wrist=form.rula_wrist.data, wrist_twist=form.rula_wrist_twist.data,
            neck=form.rula_neck.data, trunk=form.rula_trunk.data, legs=form.rula_legs.data,
            muscle_use=form.rula_muscle_use.data, force_load=form.rula_force_load.data,
        ))
        reba = compute_reba_full(dict(
            trunk=form.reba_trunk.data, neck=form.reba_neck.data, legs=form.reba_legs.data,
            upper_arm=form.reba_upper_arm.data, lower_arm=form.reba_lower_arm.data, wrist=form.reba_wrist.data,
            coupling=form.reba_coupling.data, load=form.reba_load.data,
            activity_static=form.reba_activity_static.data, activity_repeat=form.reba_activity_repeat.data, activity_rapid=form.reba_activity_rapid.data,
        ))
        li, rwl = compute_niosh(form.weight.data, form.h.data, form.v.data, form.d.data, form.a.data, form.f.data, form.c.data)
        category = max((risk_band('RULA', rula)['category'], risk_band('REBA', reba)['category']), key=lambda x: {'Low':1,'Medium':2,'High':3}[x])
        a = Assessment(jobrole_id=form.jobrole_id.data, assessor=current_user.name, observation=form.observation.data,
                       rula=rula, reba=reba, niosh_li=li, recommended_weight=rwl, risk_category=category)
        db.session.add(a); db.session.commit()

        files = request.files.getlist('media')
        for f in files:
            if not f or not f.filename: continue
            ext = os.path.splitext(f.filename)[1].lower()
            if ext not in {'.jpg','.jpeg','.png','.gif','.mp4','.mov','.avi','.webm'}: continue
            fn = f"{uuid.uuid4().hex}{ext}"
            path = os.path.join(current_app.config['UPLOAD_FOLDER'], fn)
            f.save(path)
            m = Media(assessment_id=a.id, filename=fn, original_name=f.filename, media_type=('video' if ext in {'.mp4','.mov','.avi','.webm'} else 'image'))
            db.session.add(m)
        db.session.commit()
        flash('Assessment saved','success')
        return redirect(url_for('assessments.view', assessment_id=a.id))
    return render_template('assessments/new.html', form=form)

@bp.route('/assessment/<int:assessment_id>')
@login_required
def view(assessment_id):
    a = Assessment.query.get_or_404(assessment_id)
    acts = CorrectiveAction.query.filter_by(assessment_id=a.id).all()
    return render_template('assessments/view.html', a=a, actions=acts)

@bp.route('/assessment/<int:assessment_id>/action', methods=['POST'])
@login_required
def add_action(assessment_id):
    a = Assessment.query.get_or_404(assessment_id)
    from datetime import datetime
    action = request.form.get('action'); resp = request.form.get('responsible'); due = request.form.get('due_date')
    due_d = datetime.strptime(due, '%Y-%m-%d').date() if due else None
    db.session.add(CorrectiveAction(assessment_id=a.id, action=action, responsible=resp, due_date=due_d))
    db.session.commit()
    return redirect(url_for('assessments.view', assessment_id=assessment_id))
