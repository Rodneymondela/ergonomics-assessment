# Ergonomics App (Flask)

RULA/REBA ergonomics assessments with media uploads, OCR stubs, and exports.

## Quickstart (Windows PowerShell)
```powershell
py -3 -m venv .venv
. .venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
flask --app wsgi.py db-init
flask --app wsgi.py run
```
Open: http://127.0.0.1:5000

## Features
- Auth
- Companies & Job Roles
- Assessments: RULA, REBA, NIOSH LI
- Media uploads + simple annotations
- CSV export, printable HTML report
- REST-ish JSON API (read-only samples)
- PyTest suite for core logic
